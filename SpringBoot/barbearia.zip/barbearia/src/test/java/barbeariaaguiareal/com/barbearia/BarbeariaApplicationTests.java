package barbeariaaguiareal.com.barbearia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BarbeariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
